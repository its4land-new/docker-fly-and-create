# -*- coding: utf-8 -*-
"""
/***************************************************************************
 its4land WP6: Tool Wrapper
                              -------------------
        begin                : 2019-02-26
        git sha              : $Format:%H$
        copyright            : (C) 2019 by Reiner Borchert, Hansa Luftbild AG Münster
        email                : borchert@hansaluftbild.de
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

"""
!/bin/python
-*- coding: utf-8 -*

### Author ###
 Reiner Borchert, 2019

### Description ###
 abstract base class for processing
"""

from wrapper.configuration import Configuration
from wrapper.basicprocessing import BasicProcessing

def printInfo (process, parameters):
    print("module: {0}".format(__name__))
    print("...in file: {0}".format(__file__))
    print("Project: {0}".format(process.projectName()))
    print("Tool: {0}".format(process.toolName()))
    print("Tool Version: {0}".format(process.toolVersion()))
    print("Entry Point: {0}".format(process.entryPointName()))
    print("Parameters: {0}".format(str(parameters)))

class MyProcessing (BasicProcessing):
    
    def __init__(self, process, parameters):
        super(MyProcessing, self).__init__(process, parameters)

    def start (self):
        if super(MyProcessing, self).start():
            Configuration.print("*** {0} started  ***".format(self._process.name()))
            # do your work
            if True:
                return True
        return False

    def finish (self):
        if super(MyProcessing, self).finish():
            Configuration.print("*** {0} finished  ***".format(self._process.name()))
            # do your work
            return True
        return False

    def abort (self):
        if super(MyProcessing, self).abort():
            Configuration.print("*** {0} aborted ***".format(self._process.name()))
            # do your work
            return True
        return False

