# -*- coding: utf-8 -*-
"""
/***************************************************************************
 its4land WP6: Tool Wrapper
                              -------------------
        begin                : 2019-02-26
        git sha              : $Format:%H$
        copyright            : (C) 2019 by Reiner Borchert, Hansa Luftbild AG Münster
        email                : borchert@hansaluftbild.de
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

"""
!/bin/python
-*- coding: utf-8 -*

### Author ###
 Reiner Borchert, 2019

### Description ###
 simple example for an entry points module
"""

import sys
import os
sys.path.append(os.path.split(__file__)[0])

from wrapper.configuration import Configuration
from wrapper.basicprocessing import BasicProcessing
from toolmain import MyProcessing, printInfo

def demo (process, parameters):
    printInfo(process, parameters)

    processing = MyProcessing(process, parameters)
    if processing.start():
        processing.finish()
        return True
    processing.abort()
    return False

