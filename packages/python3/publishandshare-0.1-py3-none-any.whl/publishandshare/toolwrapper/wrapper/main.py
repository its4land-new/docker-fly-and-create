# -*- coding: utf-8 -*-
"""
/***************************************************************************
 its4land WP6: Tool Wrapper
                              -------------------
        begin                : 2019-02-26
        git sha              : $Format:%H$
        copyright            : (C) 2019 by Reiner Borchert, Hansa Luftbild AG Münster
        email                : borchert@hansaluftbild.de
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""


"""
!/bin/python
-*- coding: utf-8 -*

### Author ###
 Reiner Borchert, 2019

### Description ###
 main module for running tools inside a docker container (interface)
"""

from sys import argv, stdout

from .toolclasses import Process
from .configuration import Configuration
from .publicapi import PublicAPI

QUIT = 0
RUN = 1
READY = 2
HELP = 9

parameterMessage = {QUIT:"-q:  Quit", 
                    RUN:"Enter a process UID and optional parameters",
                    HELP:"-h:  Shows this parameter list"}

autostart = False
interactive = False

def _parseArguments (args):
    """ parses command line arguments, determines the command mode and the input parameters
    
    Parameters:
        args (list):  command line arguments
    
    Returns:
        (int, list): mode ID, input parameters
    """
    arguments = {"-q":QUIT, "-h":HELP}
    modID = None
    inputParams = []
    i = 0
    for arg in args:
        if i == 1:
            modID = arguments.get(arg.lower())
        if modID is None and i > 0:
            inputParams.append(arg)
        i += 1
    if modID is None and Configuration.processUID():
        modID = RUN
    return modID, inputParams

def _executeParams (modID, inputParams):
    """ interpretes the command mode and executes the tool with the input parameters
    
    Parameters:
        modID (int):         command line arguments
        inputParams (list):  input parameters, to be passed to the tool
    
    Returns:
        (int): mode ID 
    """
    global interactive
    if modID is None:
        modID = HELP
        interactive = True
        print("*** ITS4LAND: Tool Wrapper ***")
    elif modID == READY:
        modID = QUIT
    if modID == HELP:
        print(parameterMessage[RUN])
        print(parameterMessage[HELP])
        print(parameterMessage[QUIT])
    elif modID == QUIT:
        if interactive:
            print("*** Leaving 'Tool Wrapper' - bye! ***")
    else:
        processUID = Configuration.processUID()
        if processUID:
            process = Process.loadProcess(processUID)
            if process is not None:
                toolFunc = process.getToolFunction()
                if toolFunc is None:
                    if process.toolVersion():
                        print("No processing module found!")
                    else:
                        print("Tool version missing!")
                elif toolFunc(process, inputParams):
                    return READY
                else:
                    print("Error on processing of {0}!".format(process.name()))
            else:
                print("Cound not load process {0}!".format(processUID))
        else:
            print("No Process ID found!")
        modID = HELP
    return modID

def startWrapper():
    """ collects all data for the tool from command line 
    and environment or config file, and then starts the tool wrapper    
    """
    if PublicAPI.serverConnected():
        args = argv
        if len(args) > 1 and not args[1].startswith("-") and not Configuration.processUID():
            Configuration.setProcessUID(args[1])
            del args[1]
            # print("Process UID = {0}".format(Configuration.processUID()))
        modID, inputParams = _parseArguments(args)
        if modID is not None:
            _executeParams(modID, inputParams)
        else:
            while modID != QUIT:
                if modID != READY:
                    modID, inputParams = _parseArguments(args)
                modID = _executeParams(modID, inputParams)
                if modID == HELP:
                    try:
                        cmd = argv[0] + " " + input('--> ')
                        args = cmd.split(" ")
                        if len(args) > 1 and not args[1].startswith("-"):
                            Configuration.setProcessUID(args[1])
                            del args[1]
                    except:
                        modID = QUIT
    else:
        print("URL of the Public API missing!")

if autostart:
    autostart = False
    startWrapper()