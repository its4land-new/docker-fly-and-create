# -*- coding: utf-8 -*-
"""
/***************************************************************************
                              -------------------
        begin                : 2016-06-09
        git sha              : $Format:%H$
        copyright            : (C) 2016 by Reiner Borchert / Hansa Luftbild
        email                : borchert@hansaluftbild.de
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import json

from requests import Session

class RequestController:
    """ static class for basic access to a REST interface, used by the module publicapi

    There is no need to access these functions directly from a tool.
    """
    
    __notifyFuntion = None

    # -------------------------------------------------------------------------- #
    
    _currentSession = None
    
    @staticmethod
    def connectNotification (func):
        """ sets the notification to an external function, used for notifications 

        Parameters:
            func (function): function with signature (title, message, exception = None)
            level (int):  log level
        """
        RequestController.__notifyFuntion = func

    @staticmethod
    def createCurrentSession ():
        """ creates a new session if there is none before, returns the current session
        """
        RequestController._currentSession = RequestController._getSession(True)
        return RequestController._currentSession

    @staticmethod
    def resetCurrentSession ():
        """ closes and removes the current session
        """
        if RequestController._currentSession is not None:
            try:
                RequestController._currentSession.close()
            finally:
                RequestController._currentSession = None

    @staticmethod
    def _getSession (create):
        if create:
            return Session()
        else:
            return RequestController._currentSession

    # -------------------------------------------------------------------------- #
    
    @staticmethod
    def sendGetRequest (url, requestData, useCurrentSession=True):
        """ sends a GET request to the given server url 

        Parameters:
            url (string):             server url
            requestData (dict):       data specifying the request
            useCurrentSession (bool): True: use the current session, if existing / False: create a new session
        
        Returns:
            (string):  content of the response
        """
        try:
            session = RequestController._getSession(not useCurrentSession)
            if session is not None:
                response = session.get(url, params=requestData)
                if RequestController._checkResponseError(response):
                    return response.content
        except Exception as e:
            RequestController._logRequestError (url, e)
        finally:
            if not useCurrentSession and session is not None:
                session.close() 
        return None

    @staticmethod
    def sendPutRequest (url, requestData):
        """ sends a PUT request to the given server url 

        Parameters:
            url (string):        server url
            requestData (dict):  data to be submitted to the server
        
        Returns:
            (string):  content of the response
        """
        try:
            session = RequestController._getSession(False)
            if session is not None:
                response = session.put(url, data=requestData)
                if RequestController._checkResponseError(response):
                    return response.content
        except Exception as e:
            RequestController._logRequestError (url, e)
        finally:
            pass 
        return None

    @staticmethod
    def sendPatchRequest (url, requestData):
        """ sends a PATCH request to the given server url 

        Parameters:
            url (string):        server url
            requestData (dict):  data to be submitted to the server
        
        Returns:
            (string):  content of the response
        """
        try:
            session = RequestController._getSession(False)
            if session is not None:
                response = session.patch(url, data=requestData)
                if RequestController._checkResponseError(response):
                    return response.content
        except Exception as e:
            RequestController._logRequestError (url, e)
        finally:
            pass 
        return None

    @staticmethod
    def sendPostRequest (url, requestData, useCurrentSession=True):
        """ sends a POST request to the given server url 

        Parameters:
            url (string):             server url
            requestData (dict):       data to be submitted to the server
            useCurrentSession (bool): True: use the current session, if existing / False: create a new session
        
        Returns:
            (string):  content of the response
        """
        try:
            session = RequestController._getSession(not useCurrentSession)
            if session is not None:
                response = session.post(url, data=requestData)
                if RequestController._checkResponseError(response):
                    return response.content
        except Exception as e:
            RequestController._logRequestError (url, e)
        finally:
            if not useCurrentSession and session is not None:
                session.close() 
        return None

    @staticmethod
    def sendJsonRequest (url, requestData, useCurrentSession=True):
        """ sends a POST request in JSON format to the given server url 

        Parameters:
            url (string):             server url
            requestData (dict):       data in JSON format to be submitted to the server
            useCurrentSession (bool): True: use the current session, if existing / False: create a new session
        
        Returns:
            (string):  content of the response
        """
        try:
            session = RequestController._getSession(not useCurrentSession)
            if session is not None:
                response = session.post(url, json=requestData)
                if RequestController._checkResponseError(response):
                    return response.content
        except Exception as e:
            RequestController._logRequestError (url, e)
        return None

    @staticmethod
    def sendPostFormDataRequest (url, requestData, uploadFile = None):
        """ sends a POST request from a HTML form to the given server url, uploads a file if it is specified

        Parameters:
            url (string):             server url
            requestData (dict):       data to be submitted to the server
            uploadFile (string):      name of a file to be uploaded to the server
        
        Returns:
            (string):  content of the response
        """
        try:
            files = None
            session = RequestController._getSession(False)
            if session is not None:
                if uploadFile:
                    files = {'document': open(uploadFile,'rb')}
                response = session.post(url, data=requestData, files=files)
                if RequestController._checkResponseError(response):
                    return response.content
        except Exception as e:
            RequestController._logRequestError (url, e)
        finally:
            if files:
                for (key, value,) in files.items():
                    if isinstance(value, file):
                        value.close()
        return None

    @staticmethod
    def sendDeleteRequest (url, requestData):
        """ sends a DELETE request to the given server url

        Parameters:
            url (string):             server url
            requestData (dict):       data specifying the item to be deleted
        
        Returns:
            (string):  content of the response
        """
        try:
            session = RequestController._getSession(False)
            if session is not None:
                response = session.delete(url) #, requestData)
                if RequestController._checkResponseError(response):
                    return response.content
        except Exception as e:
            RequestController._logRequestError (url, e)
        return None
    
    @staticmethod
    def downloadFile (url, fileName, useCurrentSession=True):
        """ downloads a file from the given server url

        Parameters:
            url (string):             server url
            fileName (string):        name of the file to be created from download data; 
                                      if the name is None, it will be taken from the last part of the url
            useCurrentSession (bool): True: use the current session, if existing / False: create a new session
        
        Returns:
            (string):  name of the downloaded file
        """
        try:
            session = RequestController._getSession(not useCurrentSession)
            if session is not None:
                if not fileName:
                    fileName = url.split('/')[-1]
                response = session.get(url, stream=True)
                if RequestController._checkResponseError(response):
                    with open(fileName, 'wb') as f:
                        for chunk in response.iter_content(chunk_size=4096): 
                            if chunk: # filter out keep-alive new chunks
                                f.write(chunk)
                    return fileName
        except Exception as e:
            RequestController._logRequestError (url, e)
        finally:
            if not useCurrentSession and session is not None:
                session.close() 
        return None

    # -------------------------------------------------------------------------- #
    
    _lastMessage = None
    
    @staticmethod
    def _getContentItem(content, itemID):
        if content and itemID:
            return content.get(itemID)
        return None

    @staticmethod
    def _responseToContent(response):
        if response is not None:
            items = RequestController.strToDict(response.content)
            RequestController._lastMessage = None
            if items is None:
                RequestController._lastMessage = "no content"
            else:
                success = RequestController._getContentItem(items, 'success')
                if not success:
                    RequestController._lastMessage = RequestController._getContentItem(items, 'message')
                    if not RequestController._lastMessage:
                        RequestController._lastMessage = "unknown"
            if RequestController._lastMessage is None:
                return items
            else:
                RequestController._logResponseError (response.url, response.status_code, RequestController._lastMessage)
        return None

    #@staticmethod
    #def lastMessage():
    #    try:
    #        return RequestController._lastMessage
    #    finally:
    #        RequestController._lastMessage = None

    @staticmethod
    def _contentToResult(content):
        if content:
            result = RequestController._getContentItem(content, 'result')
            if result is None:
                return []
            return result
        return None

    @staticmethod
    def _responseToResult(response):
        return RequestController._contentToResult(RequestController._responseToContent(response))

    @staticmethod
    def strToDict(content):
        """ converts a JSON string to a dict

        Parameters:
            content (string):   a JSON string, probably received from a server request

        Returns:
            (dict):  result of the conversion
        """
        if content is not None:
            try:
                return json.loads(content)
            except Exception as e:
                if RequestController.__notifyFuntion is not None:
                    RequestController.__notifyFuntion(u'JSON', u'Error on JSON decoding: {0} - message: {1}'.format(content, str(e)), e)
        return None

    @staticmethod
    def _checkResponseError (response):
        if response is not None:
            if response.ok and response.content is not None:
                return True
            RequestController._logResponseError (response.url, response.status_code, response.reason)
        return False

    # -------------------------------------------------------------------------- #
    
    @staticmethod
    def _logRequestError (url, exception):
        if RequestController.__notifyFuntion is not None:
            RequestController.__notifyFuntion('RequestController', 'Error on sending RequestController to {0}: {1}'.format(url, str(exception)), exception)

    @staticmethod
    def _logResponseError (url, code, msg):
        if RequestController.__notifyFuntion is not None:
            print(code)
            RequestController.__notifyFuntion('Response', 'Error on url {0} - code {1}: {2}'.format(url, code, msg))

