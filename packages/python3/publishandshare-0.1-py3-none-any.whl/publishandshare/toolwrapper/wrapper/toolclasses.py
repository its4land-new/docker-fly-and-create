# -*- coding: utf-8 -*-
"""
/***************************************************************************
 its4land WP6: Tool Wrapper
                              -------------------
        begin                : 2019-02-26
        git sha              : $Format:%H$
        copyright            : (C) 2019 by Reiner Borchert, Hansa Luftbild AG Münster
        email                : borchert@hansaluftbild.de
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

"""
!/bin/python
-*- coding: utf-8 -*

### Author ###
 Reiner Borchert, 2019

### Description ###
 class for tool entry points
"""

import os
import sys
from datetime import *
import logging
import uuid
import json
import importlib, importlib.util
import re

sys.path.append(os.path.split(__file__)[0]+"/..")

from .publicapi import PublicAPI


def format_tool_name(name):
    """Remove Capital letters and Spaces from tool name"""
    return re.sub('\s+', '', name).lower()

class ToolItem():
    """ abstract base class for all database items, with uid and name """

    def __init__(self, data, uid = None):
        """ constructor for a database item
    
        Parameters:
            data (dict):   item data loaded from the Public API
            uid (string):     uid of the item; if None: uid is set from data
        """
        if uid is None and isinstance(data, dict):
            self._uid = data.get("UID")
        else:
            self._uid = uid
        self._name = None

    def __str__(self):
        return self.name()

    def __repr__(self): 
       return '[%s] %s' % (self.__class__.__name__, self._name)
  
    def name (self):
        """ the name property """
        return self._name

    def uid (self):
        """ the uid property """
        return self._uid

class Process(ToolItem):
    """ class for process data
    
    Subitems:
        _project (Project)
        _tool (Tool)
        _logs (list of LogEntry)
        _results (list of ProcessResult)
    """

    @staticmethod
    def loadProcess (processUID):
        """ loads a process from the API

        Parameters:
            processUID (string):   uid of the currently running process
        
        Returns:
            (Process):  the process
        """
        data = PublicAPI.loadProcess(processUID)
        if isinstance(data, dict):
            return Process(data, processUID)
        return None

    def __init__(self, data, uid = None):
        super(Process, self).__init__(data, uid)
        self._status = data.get("Status")
        self._createdBy = data.get("CreatedBy")
        self._createdAt = data.get("CreatedAt")
        self._lastModifiedAt = data.get("LastModifiedAt")
        val = data.get("Project")
        if isinstance(val, str):
            self._project = Project.loadProject(val)
        else:
            self._project = Project(val)
        val = data.get("Tool")
        if isinstance(val, str):
            self._tool = Tool.loadTool(val)
        else:
            self._tool = Tool(val)
        if self._project is not None and self._tool is not None:
            self._name = "Tool '{0}' in Project '{1}'".format(self._tool.name(), self._project.name())
        
        self._logs = []
        val = data.get("Logs")
        if isinstance(val, (list,)):
            for log in val:
                self._logs.append(LogEntry(log))
        
        self._results = []
        val = data.get("Results")
        if isinstance(val, (list,)):
            for result in val:
                self._results.append(ProcessResult(result))

    def projectName (self):
        """ the project's name
        
        Returns:
            (string):  name of the project
        """
        if self._project is not None:
            return self._project.name()
        return None

    def toolName (self):
        """ the tool's name
        
        Returns:
            (string):  name of the tool
        """
        if self._tool is not None:
            return  format_tool_name(self._tool.name())
        return None

    def toolVersion (self):
        """ the tool's version
        
        Returns:
            (string):  version of the tool
        """
        if self._tool is not None:
            return self._tool.version()
        return None

    def _toolModuleName (self):
        """ the tool's start function name
        
        Returns:
            (string):  name and path of the start function
        """
        if self._tool is not None:
            version = self._tool.version()
            if version:
                return "{0}.{1}.entrypoints".format(self.toolName(), version.replace(".", "_"))
            #else:
            #    return "{0}.entrypoints".format(self.toolName())
        return None

    def _toolPackagePath (self):
        """ the tool's start function name
        
        Returns:
            (string):  name and path of the start function
        """
        if self._tool is not None:
            version = self._tool.version()
            if version:
                return "{0}/{1}/entrypoints.py".format(self.toolName(), version.replace(".", "_"))
            #else:
            #    return "{0}/entrypoints.pay".format(self.toolName())
        return None

    def entryPointName (self):
        """ the entry point's name
        
        Returns:
            (string):  name of the entry point
        """
        if self._tool is not None:
            return self._tool.entryPointName().lower()
        return None

    def project (self):
        """ the project which has started this process
        
        Returns:
            (Project):  the project
        """
        return self._project

    def tool (self):
        """ the tool to be started in this process
        
        Returns:
            (Tool):  the tool
        """
        return self._tool

    def entryPoint (self):
        """ the entry point of the tool
        
        Returns:
            (EntryPoint):  the entry point
        """
        if self._tool is not None:
            return self._tool.entryPoint()
        return None

    def parameters (self):
        """ the parameters of the tool's entry point
        
        Returns:
            (dict):  parameters
        """
        if self._tool is not None:
            return self._tool.parameters()
        return None

    def logs (self):
        """ the process logs
        
        Returns:
            (list of LogEntry):  log entries of the process
        """
        return self._logs

    def addLog (self, logMessage, level, source):
        """ adds a new log entry

        Parameters:
            logMessage (string):   message text
            level (string):        log level
            source (string):       origin of the log
        
        Returns:
            (dict):  new log entry
        """
        log = {}
        log["LogMsg"] = logMessage
        log["LogLevel"] = level
        log["LogSource"] = source
        log = PublicAPI.saveLogEntry(self._uid, log)
        if log is not None:
            entry = LogEntry(log)
            self._logs.append(entry)
            return entry
        return None

    def results (self):
        """ the current results of the process
        
        Returns:
            (list of ProcessResult):  list of process results
        """
        return self._results

    def getToolFunction(self):
        """ tries to detect the function to call the tool's entry point, identified by the tool's name, version and entry point

        Returns:
            (function):  function to start the tool
        """
        try:
            name = self._toolModuleName() # the module name
            if name:
                #print("Path: " + str(sys.path))
                importlib.invalidate_caches()
                procModule = importlib.import_module(name) #, self._toolPackagePath())
                if procModule is not None:
                    name = self.entryPointName()  # the function name
                    if name:
                        return getattr(procModule, name)
                    return procModule
        except ImportError as exc:
            print(sys.path)
            print(exc)
            pass
        except Exception as exc:
            print(exc)
            pass
        return None

class Tool(ToolItem):
    """ class for tool data
    
    Subitem of Process
    Subitems:
        _entryPoints (list of EntryPoint)
    """

    @staticmethod
    def loadTool (toolUID):
        """ loads a tool from the API

        Parameters:
            toolUID (string):   uid of the tool
        
        Returns:
            (Tool):  the tool
        """
        data = PublicAPI.loadTool(toolUID)
        if isinstance(data, dict):
            return Tool(data, toolUID)
        return None

    def __init__(self, data, uid = None):
        super(Tool, self).__init__(data, uid)
        self._name = data.get("ToolName")
        self._version = data.get("Version")
        self._entryPoints = []
        epoints = data.get("EntryPoint")
        if isinstance(epoints, (list,)):
            for item in epoints:
                self._entryPoints.append(EntryPoint(item))
        elif epoints is not None:
            self._entryPoints.append(EntryPoint(epoints))

    def version (self):
        """ version property
        
        Returns:
            (string):  version of the tool
        """
        return self._version

    def entryPointName (self):
        """ the entry point's name
        
        Returns:
            (string):  name of the entry point
        """
        entryPoint = self.entryPoint()
        if entryPoint is not None:
            return entryPoint.name()
        return None

    def entryPoint (self):
        """ the entry point
        
        Returns:
            (EntryPoint):  the entry point
        """
        if len(self._entryPoints) > 0:
            return self._entryPoints[0]
        return None

    def entryPoints (self):
        """ all entry points of the tool
        
        Returns:
            (list of EntryPoint):  the entry points
        """
        return self._entryPoints

    def parameters (self):
        """ the parameters of the entry point
        
        Returns:
            (dict):  parameters
        """
        entryPoint = self.entryPoint()
        if entryPoint is not None:
            return entryPoint._parameters
        return None


class EntryPoint(ToolItem):
    """ class for entry point data
    
    Subitem of Tool
    Subitems:
        _parameters (dict)
    """
    
    @staticmethod
    def loadEntryPoints (toolUID):
        """ retrieves all entry points of a tool from the API

        Parameters:
            toolUID (string):   uid of the tool
        
        Returns:
            (list of EntryPoint):  list of entry points
        """
        if toolUID:
            epoints = PublicAPI.getEntryPoints(toolUID)
            if isinstance(epoints, (list,)):
                entryPoints = []
                for item in epoints:
                    entryPoints.append(EntryPoint(item))

    def __init__(self, data, uid = None):
        super(EntryPoint, self).__init__(data, uid)
        self._name = data.get("EntryPointName")
        self._parameters = {}
        params = data.get("Parameter")
        if isinstance(params, (list,)):
            for param in params:
                pname = param.get("ParameterName")
                if pname:
                    self._parameters[pname] = param.get("ParameterValue")

    def parameters (self):
        """ the parameters of the entry point
        
        Returns:
            (dict):  parameters
        """
        return self._parameters

    def getEntryPointFunction (self, object, default = None):
        """ tries to find the function referenced by the entry point

        Parameters:
            object (object):   module object
            default (object):  returned if the search fails
        
        Returns:
            (function):  function of the entry point
        """
        return getattr(object, self._name, default)

class LogEntry(ToolItem):
    """ class for log entry data

    Subitem of Process
    """
    
    @staticmethod
    def loadLogEntries (processUID):
        """ loads log entries of a process from the API

        Parameters:
            processUID (string):   uid of the currently running process
        
        Returns:
            (list of LogEntry):  log entries
        """
        data = PublicAPI.loadLogEntries(processUID)
        if data is not None:
            result = []
            for entry in data:
                result.append(LogEntry(entry))
            return result
        return None

    def __init__(self, data, uid = None):
        super(LogEntry, self).__init__(data, uid)
        self._name = data.get("LogMsg")
        self._seqNr = data.get("SeqNr")
        self._level = data.get("LogLevel")
        self._date = data.get("LogDate")
        self._source = data.get("LogSource")

    def message (self):
        """ message text of this log entry
        
        Returns:
            (string):  message text
        """
        return self._name

    def sequenceNumber (self):
        """ sequence number of this log entry
        
        Returns:
            (int):  sequence number
        """
        return self._seqNr

    def level (self):
        """ level of this log entry
        
        Returns:
            (string):  level (DEBUG, INFO, WARNING, ERROR, FATAL)
        """
        return self._level

    def date (self):
        """ creation date of this log entry
        
        Returns:
            (string):  creation date
        """
        return self._date

    def source (self):
        """ source of this log entry
        
        Returns:
            (string):  source
        """
        return self._source

    def _sequelize (self):
        """ convert to dict for posting to the Public API 
        
        Returns:
            (dict)
        """
        result = {}
        result["LogMsg"] = self._name
        result["SeqNr"] = self._seqNr
        result["LogLevel"] = self._level
        result["LogDate"] = self._date
        result["LogSource"] = self._source
        return result

class ProcessResult(ToolItem):
    """ class for process result data

    Subitem of Process
    """
    
    def __init__(self, data, uid = None):
        super(ProcessResult, self).__init__(data, uid)
        self._uid = data.get("ResultUID")
        self._name = self._uid
        self._resultType = data.get("ResultType")

    def resultType (self):
        """ result type of this process result
        
        Returns:
            (string):  result type
        """
        return self._resultType

    def _sequelize (self):
        """ convert to dict for posting to the Public API 
        
        Returns:
            (dict)
        """
        result = {}
        result["ResultUID"] = self._uid
        result["ResultType"] = self._resultType
        return result

class Project(ToolItem):
    """ class for project data
    
    Subitem of Process
    """
    
    @staticmethod
    def loadProject (projectUID):
        """ loads data of a project from the API

        Parameters:
            projectUID (string):   uid of the project
        
        Returns:
            (Project):  project
        """
        data = PublicAPI.loadProject(projectUID)
        if isinstance(data, dict):
            return Project(projectUID, data)
        return None

    def __init__(self, data, uid = None):
        super(Project, self).__init__(data, uid)
        self._name = data.get("Name")
        self._description = data.get("Description")
        self._projectDir = data.get("ProjectDir")
        self._areaOfInterest = data.get("aoi")
        
    def description (self):
        """ description of the project

        Returns:
            (string)
        """
        return self._description
    
    def projectDir (self):
        """ directory of the project

        Returns:
            (string)
        """
        return self._projectDir

    def areaOfInterest (self):
        """ area of interest in the project

        Returns:
            (string)
        """
        return self._areaOfInterest
    