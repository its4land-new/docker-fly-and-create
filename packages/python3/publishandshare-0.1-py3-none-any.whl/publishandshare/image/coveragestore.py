"""
!/bin/python
-*- coding: utf-8 -*

/***************************************************************************
 its4land WP6: PublishLayer
                              -------------------
        begin                : 2019-01-14
        git sha              : $Format:%H$
        copyright            : (C) 2019 by Reiner Borchert, Hansa Luftbild AG Münster
        email                : borchert@hansaluftbild.de
  ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

# Import required modules
import os
import math
import json
import logging
import datetime

from .requestcontroller import RequestController
from .basicprocessing import BasicProcessing

class CoverageStore(BasicProcessing):

    def __init__(self, filename, coverage_name):
        super(CoverageStore, self).__init__()
        self._geoserver_URL = self._config_value("GeoserverURL")
        self._source_URL = self._config_value("StorageURL")
        self._storages_base_URL = self._geoserver_URL + self._config_value("WorkspacesFolder") + self._config_value("WorkspaceStorages")
        self._filename = filename
        self._coverage_name = coverage_name
        body = self._config_value("StorageBody")
        if body is not None:
            body["coverageStore"]["workspace"]["atom:link"]["-href"] = self._geoserver_URL + self._config_value("WorkspaceXML")
            body["coverageStore"]["name"] = self._coverage_name
            body["coverageStore"]["url"] = self._source_URL + self._filename
        body = self._config_value("CoverageBody")
        if body is not None:
            basename, ext = os.path.splitext(self._filename)
            body["coverage"]["nativeName"] = basename
        RequestController.create_current_session (self._config_value("GeoserverUsername"), self._config_value("GeoserverPassword"))
        
    def store_coverage_file (self):
        body = self._config_value("StorageBody")
        if body is not None:
            response = RequestController.send_post_request(self._storages_base_URL, body)
            return response
        return None
        
    def register_coverage (self, layer_name):
        body = self._config_value("CoverageBody")
        if body is not None:
            body["coverage"]["name"] = layer_name
            body["coverage"]["abstract"] = (f"Added on {datetime.datetime.now().replace(microsecond=0).isoformat()} "
                                            "by Publish & Share image registration tool")
            print (body)
            response = RequestController.send_post_request(self._storages_base_URL + self._coverage_name + "/coverages", body)
            return response
        return None
