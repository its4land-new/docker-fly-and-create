"""
!/bin/python
-*- coding: utf-8 -*

/***************************************************************************
 its4land WP6: PublishLayer
                              -------------------
        begin                : 2019-01-14
        git sha              : $Format:%H$
        copyright            : (C) 2019 by Reiner Borchert, Hansa Luftbild AG Münster
        email                : borchert@hansaluftbild.de
  ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

# Import required modules
import os
import math
import json
import logging

from .requestcontroller import RequestController
from .basicprocessing import BasicProcessing

class AddLayer(BasicProcessing):

    def __init__(self, layerName):
        super(AddLayer, self).__init__()

        self._expermapsURL = self._config_value("ExpermapsURL")
        self._geoserverURL = self._config_value("GeoserverURL")
        
        self._layerName = layerName
        self._layerID = None
        
        body = {}
        body["username"] = self._config_value("ExperMapsUsername")
        body["password"] = self._config_value("ExperMapsPassword")
        RequestController.create_current_session()
        self._session = RequestController.send_post_request(self._expermapsURL + "login", body)
        
    def _get_projections (self):
        if self._session is not None:
            response = RequestController.send_get_request(self._expermapsURL + "db/projections", {})
            response_str = json.loads(response, encoding="UTF-8")
            projections = [ x['_id'] for x in response_str['projections']]
            return projections
        return None
        
    def add_layer (self):
        body = self._config_value("AddLayerBody")
        if self._session is not None and body is not None:
            projections = self._get_projections()
            body["name"] = self._layerName
            body["dataConfig"]["src"] = self._geoserverURL + 'wms'
            body["dataConfig"]["layer"] = self._layerName
            body["availableProjectionSets"] = projections
            response_bytes = RequestController.send_post_request(self._expermapsURL + "db/layers", body)
            response = json.loads(response_bytes, encoding="UTF-8")
            if response["success"]:
                self._layerID = response["id"]
                return self._layerID
        return None
        
    def _get_roles (self):
        if self._session is not None:
            response = RequestController.send_get_request(self._expermapsURL + "db/roles", {})
            response_str = json.loads(response, encoding="UTF-8")
            return response_str
        return None
    
    def _get_default_role (self):
        roles = self._get_roles()
        if roles is not None:
            defaultRole = [ x for x in roles['roles'] if x['name']=='defaultRole'][0]
            return defaultRole
        return None
    
    def update_default_role (self):
        role = self._get_default_role()
        if role is not None and self._layerID is not None:
            role["rights"]["<layer>"+self._layerID] = {"type":"layer","create":False, "update":False, "delete":False, "updateAttributes":False}
            RequestController.send_put_request(self._expermapsURL + "db/roles", role)
            return True
        return False

    def _get_layer_hierarchy (self):
        if self._session is not None:            
            response =  RequestController.send_get_request(self._expermapsURL + "db/layerhierarchy", {})
            response_str = json.loads(response, encoding="UTF-8")
            return response_str['layerHierarchy']
        return None
    
    def update_layer_hierarchy (self):
        layers = self._get_layer_hierarchy()
        if layers is not None and self._layerID is not None:
            body = self._config_value("LayerDisplayBody")
            if body is not None:
                body["id"] = self._layerID
                layers["layerDisplayOrder"].append(body)
                body = self._config_value("LayerTreeBody")
                layerTree = layers["layerTree"]
                if body is not None and layerTree is not None:
                    body["id"] = self._layerID
                    body["layerIndex"] = len(layerTree) 
                    layerTree.append(body)
                    self._layerID = RequestController.send_post_request(self._expermapsURL + "db/layerhierarchy", layers)
                    return True
        return False

    