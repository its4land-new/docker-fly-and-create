# -*- coding: utf-8 -*-
"""
/***************************************************************************
 its4land WP6: Tool Wrapper
                              -------------------
        begin                : 2019-02-26
        git sha              : $Format:%H$
        copyright            : (C) 2019 by Reiner Borchert, Hansa Luftbild AG Münster
        email                : borchert@hansaluftbild.de
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

"""
!/bin/python
-*- coding: utf-8 -*

### Author ###
 Reiner Borchert, 2019

### Description ###
 abstract base class for processing
"""

import importlib

PROCSTATE_NONE = 0
PROCSTATE_ERROR = -1
PROCSTATE_INITIATED = 1
PROCSTATE_RUNNING = 2
PROCSTATE_FINISHED = 3
PROCSTATE_ABORTED = 4

class BasicProcessing():
    """ basic class for processing a tool

    can be used for subclassing in your own tool
    
    Subitems:
        _process (Process)
    """

    
    def __init__(self, process, parameters = None):
        """ constructor for processing a tool
    
        state: PROCSTATE_INITIATED
        Parameters, passed from the tool wrapper:
            process (Process):         process data loaded from the Public API
            parameters (list of str):  command line parameters
        """
        self._state = PROCSTATE_NONE
        self._process = process;
        self._parameters = parameters
        if self.tool() is not None:
            self._state = PROCSTATE_INITIATED
        else:
            PROCSTATE_ERROR = -1

    def start (self):
        """ starts the processing of the tool

        sets state to PROCSTATE_RUNNING
        adds a log entry
        does nothing else
        should be expanded in your derived class
    
        Returns:
            (bool): success or not
        """
        if self._state == PROCSTATE_INITIATED:
            self._state = PROCSTATE_RUNNING
            self.addLogEntry("Tool processing started", "info", "PuS Wrapper")
            return True
        return False

    def finish (self):
        """ finishes the processing of the tool

        sets state to PROCSTATE_FINISHED
        adds a log entry
        does nothing else
        should be expanded in your derived class
    
        Returns:
            (bool): success or not
        """
        if self._state == PROCSTATE_RUNNING:
            self._state = PROCSTATE_FINISHED
            self.addLogEntry("Tool processing terminated", "info", "PuS Wrapper")
            return True
        if self._state == PROCSTATE_INITIATED:
            self._state = PROCSTATE_NONE
        return False

    def abort (self):
        """ aborts the processing of the tool

        sets state to PROCSTATE_ABORTED
        adds a log entry
        should be expanded in your derived class
    
        Returns:
            (bool): success or not
        """
        if self._state == PROCSTATE_RUNNING:
            self._state = PROCSTATE_ABORTED
            self.addLogEntry("Tool processing aborted ", "info", "PuS Wrapper")
            return True
        elif self._state == PROCSTATE_INITIATED:
            self._state = PROCSTATE_NONE
        return False

    def addLogEntry (self, logMessage, level="info", source="PuS Wrapper"):
        """ creates a new log entry and prints it on screen

        Parameters:
            logMessage (string): message text
            level (string):      log level
            source (string):     origin of the log
        
        Returns:
            (LogEntry):  new log entry
        """
        if self._process is not None:
            print ("Adding log - {}\n{}\n{}".format(logMessage, level, source))
            return self._process.addLog(logMessage, level, source)
        return None

    def state (self):
        """ the state of the tool's processing
        
        Returns:
            (int):  state
        """
        return self._state

    def commandParameters (self):
        """ list of command line parameters, passed by the wrapper
        
        Returns:
            (list of string):  state
        """
        return self._parameters

    def processName (self):
        """ the process's name
        
        Returns:
            (string):  name of the process
        """
        if self._process is not None:
            return self._process.name()
        return None

    def projectName (self):
        """ the project's name
        
        Returns:
            (string):  name of the project
        """
        if self._process is not None:
            return self._process.projectName()
        return None

    def toolName (self):
        """ the tool's name
        
        Returns:
            (string):  name of the tool
        """
        if self._process is not None:
            return self._process.toolName()
        return None

    def toolVersion (self):
        """ the tool's version
        
        Returns:
            (string):  version of the tool
        """
        if self._process is not None:
            return self._process.toolVersion()
        return None

    def entryPointName (self):
        """ the entry point's name
        
        Returns:
            (string):  name of the entry point
        """
        if self._process is not None:
            return self._process.entryPointName()
        return None

    def process (self):
        """ the process
        
        Returns:
            (Process):  the process
        """
        return self._process

    def project (self):
        """ the project which has started the process
        
        Returns:
            (Project):  the project
        """
        if self._process is not None:
            return self._process._project
        return None
    
    def tool (self):
        """ the tool to be started in the process
        
        Returns:
            (Tool):  the tool
        """
        if self._process is not None:
            return self._process._tool
        return None

    def entryPoint (self):
        """ the entry point of the tool
        
        Returns:
            (EntryPoint):  the entry point
        """
        if self._process is not None:
            return self._process.entryPoint()
        return None

    def toolParameters (self):
        """ the parameters of the tool's entry point
        
        Returns:
            (dict):  parameters
        """
        if self._process is not None:
            return self._process.parameters()
        return None

    def logs (self):
        """ the process logs
        
        Returns:
            (list of LogEntry):  log entries of the process
        """
        if self._process is not None:
            return self._process._logs
        return None

    def results (self):
        """ the current results of the process
        
        Returns:
            (list of ProcessResult):  list of process results
        """
        if self._process is not None:
            return self._process._results
        return None

    def _getEntryPointFunction (self):
        entryPoint = self.entryPoint()
        if entryPoint is not None:
            return entryPoint.getEntryPointFunction(self)
        return None

    def _executeThisEntryPoint (self, object = None, defaultFunction = None):
        if object is None:
            object = self
        if defaultFunction is None:
            defaultFunction = self._standardProcessing
        return BasicProcessing._executeEntryPoint(object, self.entryPointName(), self.toolParameters(), defaultFunction)

    def _standardProcessing (self, parameters):
        print("standardProcessing")
        return True

    @staticmethod
    def _executeEntryPoint (object, entryPointName, parameters, defaultFunction = None):
        if isinstance(object, str):
            object = importlib.import_module(object)
        func = entryPointName
        if isinstance(func, str):
            func = getattr(object, func, None)
        if func is not None:
            return func(parameters)
        if defaultFunction is not None:
            return BasicProcessing.executeEntryPoint (object, defaultFunction, parameters, None)
        print("Could not execute entrypoint '{0}'!".format(entryPointName))
        return None

    