# -*- coding: utf-8 -*-
"""
/***************************************************************************
 its4land WP6: Tool Wrapper
                              -------------------
        begin                : 2019-02-26
        git sha              : $Format:%H$
        copyright            : (C) 2019 by Reiner Borchert, Hansa Luftbild AG Münster
        email                : borchert@hansaluftbild.de
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import os
import json

from .requestcontroller import RequestController

class PublicAPI:
    """ static class for access to the Public API
    """
    
    _processURL = "processes"
    _toolsURL = "tools"
    _projectURL = "projects"
    
    _serverURL = None

    @staticmethod
    def serverURL ():
        """ provides the server's url """
        return PublicAPI._serverURL

    @staticmethod
    def setServerURL (url):
        """ sets the server's url
    
            Parameters:
                url (string):  url of the Public API server
        """
        if url:
            PublicAPI._serverURL = url
            RequestController.createCurrentSession()
        else:
            RequestController.resetCurrentSession()
            PublicAPI._serverURL = None

    @staticmethod
    def serverConnected ():
        """ checks if the Public API url is set """
        return bool(PublicAPI._serverURL)

    # -------------------------------------------------------------------------- #
    
    @staticmethod
    def _add2url (url, add):
        if add:
            if url:
                if add.startswith("?"):
                    return url + add
                return "{0}/{1}".format(url, add)
            return add
        return url

    @staticmethod
    def _getEndpointUrl (endpoint, uid = None):
        return PublicAPI._add2url(PublicAPI._add2url(PublicAPI._serverURL, endpoint), uid);

    @staticmethod
    def sendGetRequest (endpoint, uid = None, add = None):
        """ sends a GET request to the given endpoint, with optional specifications 

        Parameters:
            endpoint (string):        endpoint name
            uid (string):             uid of an existing database item (optional)
            add (string):             additional specification behind the uid (optional)
        
        Returns:
            (dict):  the requested database item
        """
        return RequestController.strToDict(
            RequestController.sendGetRequest(
                PublicAPI._getEndpointUrl(endpoint, PublicAPI._add2url(uid, add)), {}))

    @staticmethod
    def sendPostRequest (endpoint, uid = None, add = None, data = {}):
        """ sends a POST request to the given endpoint, with optional specifications 

        Parameters:
            endpoint (string):        endpoint name
            uid (string):             uid of an existing database item (optional)
            add (string):             additional specification behind the uid (optional)
            data (dict):              item data to be posted
        
        Returns:
            (dict):  the requested database item
        """
        return RequestController.strToDict(
            RequestController.sendJsonRequest(
                PublicAPI._getEndpointUrl(endpoint, PublicAPI._add2url(uid, add)), data))

    # -------------------------------------------------------------------------- #
    
    @staticmethod
    def loadProcess (processUID):
        """ loads data of a process from the API, including project data and log entries

        Parameters:
            processUID (string):   uid of the currently running process
        
        Returns:
            (dict):  process data
        """
        result = PublicAPI.sendGetRequest(PublicAPI._processURL, processUID, "?embed=Project,Logs")
        if result:
            return result
        return None

    @staticmethod
    def loadLogEntries (processUID):
        """ loads log entries of a process from the API

        Parameters:
            processUID (string):   uid of the currently running process
        
        Returns:
            (list):  log entries
        """
        result = PublicAPI.sendGetRequest(PublicAPI._processURL, processUID, "log")
        if result:
            return result
        return None

    @staticmethod
    def saveLogEntry (processUID, logEntry):
        """ saves a new log entry of a process

        Parameters:
            processUID (string):   uid of the currently running process
            logEntry (dict):       data of a new log entry
        
        Returns:
            (dict):  new log entry
        """
        result = PublicAPI.sendPostRequest(PublicAPI._processURL, processUID, "log", logEntry)
        if result:
            return result
        return None

    @staticmethod
    def loadTool (toolUID):
        """ loads tool data from the API

        Parameters:
            toolUID (string):   uid of the tool
        
        Returns:
            (dict):  tool data
        """
        result = PublicAPI.sendGetRequest(PublicAPI._toolsURL, "?uid={0}".format(toolUID))
        if result:
            return result
        return None

    @staticmethod
    def getEntryPoints (toolUID):
        """ retrieves all entry points of a tool from the API

        Parameters:
            toolUID (string):   uid of the tool
        
        Returns:
            (list):  list of entry point data
        """
        result = PublicAPI.loadTool(toolUID)
        if result:
            return result["EntryPoints"]
        return None

    @staticmethod
    def loadProject (projectUID):
        """ loads data of a project from the API

        Parameters:
            projectUID (string):   uid of the project
        
        Returns:
            (dict):  project data
        """
        result = PublicAPI.sendGetRequest(PublicAPI._projectURL, projectUID)
        if result:
            return result
        return None

    
