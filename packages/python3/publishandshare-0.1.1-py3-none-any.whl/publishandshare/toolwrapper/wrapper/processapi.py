# -*- coding: utf-8 -*-
"""
/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import os
import json

from requestcontroller import RequestController

class ProcessAPI:
    
    _serverURL = None

    _processURL = "process"
    _containersURL = "containers"
    _toolImagesURL = "toolImages"

    _add2urlFmt = "{0}/{1}"

    @staticmethod
    def loadConfig (fileName):
        configFileName = os.path.join(os.path.split(__file__)[0], fileName)
        configfile = open(configFileName)
        configuration = json.load(configfile)
        ProcessAPI.setServerURL(configuration["ServerURL"])

    @staticmethod
    def serverConnected ():
        return bool(ProcessAPI._serverURL)

    @staticmethod
    def setServerURL (url):
        if url:
            ProcessAPI._serverURL = url
            RequestController.createCurrentSession()
        else:
            ProcessAPI._serverURL = None

    # -------------------------------------------------------------------------- #
    
    @staticmethod
    def _add2url (url, add):
        if add:
            if url:
                return ProcessAPI._add2urlFmt.format(url, add)
            return add
        return url

    @staticmethod
    def _getEndpointUrl (endpoint, uid = None):
        return ProcessAPI._add2url(ProcessAPI._add2url(ProcessAPI._serverURL, endpoint), uid);

    @staticmethod
    def _sendGetRequest (endpoint, uid = None, add = None):
        return RequestController.strToDict(
            RequestController.sendGetRequest(
                ProcessAPI._getEndpointUrl(endpoint, ProcessAPI._add2url(uid, add)), {}))

    @staticmethod
    def _sendPostRequest (endpoint, add = None, data = {}):
        return RequestController.strToDict(
            RequestController.sendPostRequest(
                ProcessAPI._getEndpointUrl(endpoint, add), data))

    # -------------------------------------------------------------------------- #
    
    @staticmethod
    def getToolImages ():
        result = ProcessAPI._sendGetRequest(ProcessAPI._toolImagesURL)
        return result

    @staticmethod
    def getToolImage (uid):
        result = ProcessAPI._sendGetRequest(ProcessAPI._toolImagesURL, uid)
        return result

    # -------------------------------------------------------------------------- #
    
    @staticmethod
    def createContainer (params):
        result = ProcessAPI._sendPostRequest(ProcessAPI._containersURL, "create", params)
        if result is not None:
            return result.get("CID")
        return None

    @staticmethod
    def startContainer (cid):
        result = ProcessAPI._sendGetRequest(ProcessAPI._containersURL, cid, "start")
        return result

    @staticmethod
    def stopContainer (cid):
        result = ProcessAPI._sendGetRequest(ProcessAPI._containersURL, cid, "stop")
        return result

    @staticmethod
    def killContainer (cid):
        result = ProcessAPI._sendGetRequest(ProcessAPI._containersURL, cid, "kill")
        return result

    @staticmethod
    def removeContainer (cid):
        result = ProcessAPI._sendGetRequest(ProcessAPI._containersURL, cid, "remove")
        return result

    # -------------------------------------------------------------------------- #
    
    @staticmethod
    def createProcess (params):
        result = ProcessAPI._sendPostRequest(ProcessAPI._processURL, "create", params)
        if result is not None:
            return result.get("PID")
        return None

    @staticmethod
    def runProcess (params):
        result = ProcessAPI._sendPostRequest(ProcessAPI._processURL, "run", params)
        if result is not None:
            return result.get("PID")
        return None

    @staticmethod
    def getProcess (pid):
        result = ProcessAPI._sendGetRequest(ProcessAPI._processURL, pid)
        return result

    @staticmethod
    def stopProcess (pid):
        result = ProcessAPI._sendGetRequest(ProcessAPI._processURL, pid, "stop")
        return result

    @staticmethod
    def enqueueProcess (pid):
        result = ProcessAPI._sendGetRequest(ProcessAPI._processURL, "enqueue", pid)
        return result

    @staticmethod
    def dequeueProcess ():
        result = ProcessAPI._sendGetRequest(ProcessAPI._processURL, "dequeue")
        return result

    @staticmethod
    def getAllProcessInfos ():
        result = ProcessAPI._sendGetRequest(ProcessAPI._processURL, "all", "info")
        return result

 
