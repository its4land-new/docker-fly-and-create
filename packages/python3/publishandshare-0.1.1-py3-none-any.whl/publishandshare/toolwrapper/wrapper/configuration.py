# -*- coding: utf-8 -*-
"""
/***************************************************************************
 its4land WP6: Tool Wrapper
                              -------------------
        begin                : 2019-02-26
        git sha              : $Format:%H$
        copyright            : (C) 2019 by Reiner Borchert, Hansa Luftbild AG Münster
        email                : borchert@hansaluftbild.de
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

"""
!/bin/python
-*- coding: utf-8 -*

### Author ###
 Reiner Borchert, 2019

### Description ###
 abstract base class for processing
"""

import os
from datetime import *
import logging
import uuid
import json
from .requestcontroller import RequestController
from .publicapi import PublicAPI

class Configuration():
    """ static class for reading a config file, providing config data and environment variables
    """

    CONFIG_FILENAME = 'config.json'
    """ default config file name """
    
    ENVVAR_PUBLICAPIURL = 'I4L_PUBLICAPIURL'
    """ name of the environment variable for the Public API url """
    ENVVAR_PROCESSUID = 'I4L_PROCESSUID'
    """ name of the environment variable for the tool's process uid """
    ENVVAR_PROJECTUID = 'I4L_PROJECTUID'
    """ name of the environment variable for the current project uid """

    _instance = None
    """ singleton instance of the configuration """

    @staticmethod
    def load(configFileName = None, basePath = None):
        """ loads a config file
    
        Parameters:
            configFileName (str):  name of the config file, if None: uses standard 'config.json'
            basePath (str): path of the tool's working directory, if None: path of this file
        """
        if not configFileName:
            configFileName = Configuration.CONFIG_FILENAME
        Configuration.stopLogging()
        Configuration(configFileName, basePath)

    @staticmethod
    def startLogging(fileName, level=logging.DEBUG):
        """ creates or opens a log file and starts logging

        Parameters:
            fileName (str):  name of the log file
            level (int):  log level
        """
        if Configuration._instance is not None:
            Configuration._instance._startLogging(fileName, level)
    
    @staticmethod
    def stopLogging():
        """ stops logging and closes the log file (if started before)
        """
        if Configuration._instance is not None:
            Configuration._instance._stopLogging()

    @staticmethod
    def print (message, level=logging.DEBUG):
        """ prints an error message to the screen and the log file

        Parameters:
            message (str):  message text
            level (int):  log level
        """
        if Configuration._instance is not None:
            Configuration._instance._print(message, level)

    @staticmethod
    def _errorMessage(title, message, exception = None):
        """ prints an error message to the screen and the log file - to be connected with the RequestController for notifications

        Parameters:
            title (str):  title for the message
            message (str):  error message
            exception:  exception if there is noe thrown
        """
        Configuration.print('{0}: {1}'.format(title, message), level=logging.ERROR)

    @staticmethod
    def configValue(key, logError = False):
        """ gets the value of a config key
    
        Parameters:
            key (str):  name of the config key
            logError (bool): if True: logs any error, e.g. "key not found"
    
        Returns:
            value of the key/value pair
        """
        return Configuration._instance._configValue(key, logError)

    @staticmethod
    def inputFilePath(fileName):
        """ combines a filename with the input path
    
        Parameters:
            fileName (str):  any filename
    
        Returns:
            absolute path of the input file
        """
        return Configuration._instance._getInputFilePath(fileName)

    @staticmethod
    def tempFilePath(fileName):
        """ combines a filename with the temp path
    
        Parameters:
            fileName (str):  any filename
    
        Returns:
            absolute path of the temp file
        """
        return Configuration._instance._getTempFilePath(fileName)

    @staticmethod
    def outputFilePath(fileName):
        """ combines a filename with the output path
    
        Parameters:
            fileName (str):  any filename
    
        Returns:
            absolute path of the output file
        """
        return Configuration._instance._getOutputFilePath(fileName)

    @staticmethod
    def processingModule():
        """ provides the tool's mudule
        """
        return Configuration._instance._processingModule

    @staticmethod
    def toolFunction():
        """ provides the tool's start function for the entry point
        """
        return Configuration._instance._toolFunction

    @staticmethod
    def publicApiURL ():
        """ provides the url of the Public API from the environment variable 'I4L_PUBLICAPIURL'
        """
        return os.environ.get(Configuration.ENVVAR_PUBLICAPIURL)

    @staticmethod
    def processUID ():
        """ provides the uid of the running tool's process from the environment variable 'I4L_PROCESSUID'
        """
        return os.environ.get(Configuration.ENVVAR_PROCESSUID)

    @staticmethod
    def projectUID ():
        """ provides the uid of the current project of the tool from the environment variable 'I4L_PROJECTUID'
        """
        return os.environ.get(Configuration.ENVVAR_PROJECTUID)

    @staticmethod
    def setPublicApiURL (url):
        """ sets the environment variable 'I4L_PUBLICAPIURL'

        Parameters:
            url (str):  url of the Public API
        """
        os.environ[Configuration.ENVVAR_PUBLICAPIURL] = url

    @staticmethod
    def setProcessUID (processUID):
        """ sets the environment variable 'I4L_PROCESSUID' as uid of the running process

        Parameters:
            processUID (str):  uid of the running process
        """
        os.environ[Configuration.ENVVAR_PROCESSUID] = processUID

    @staticmethod
    def setProjectUID (projectUID):
        """ sets the environment variable 'I4L_PROCESSUID' as uid of the current project

        Parameters:
            projectUID (str):  uid of the current project
        """
        os.environ[Configuration.ENVVAR_PROJECTUID] = projectUID

    def __init__(self, configFileName, basePath = None):
        #""" constructor for the singleton instance, loads and reads the config file

        #Parameters:
        #    configFileName (str):  name of the config file, if None: uses standard 'config.json'
        #    basePath (str): path of the tool's working directory, if None: path of this file
        #"""
        Configuration._instance = self
        self._basePath = basePath
        if not self._basePath:
            self._basePath = os.path.split(__file__)[0]
        if not os.path.isabs(configFileName):
            configFileName = os.path.join(self._basePath, configFileName)
        configFile = open(configFileName)
        try:
            self._configuration = json.load(configFile)
        finally:
            configFile.close()

        self._showConsoleLogging = False
        self._isLogging = False
        self._showConsoleLogging = self._configValue("ShowConsoleLogging") > 0
        self._inputDataPath = self._configValue("InputDataPath")
        self._tempDataPath = self._configValue("TempDataPath")
        self._outputDataPath = self._configValue("OutputDataPath")
        self._startLogging(self._getTempFilePath(self._configValue("LogfileName")))

        self._processingModule = self._configValue("ProcessingModule")
        self._toolFunction = self._configValue("ToolFunction")
        if not Configuration.publicApiURL():
            Configuration.setPublicApiURL(self._configValue("PublicAPI"))
        PublicAPI.setServerURL(Configuration.publicApiURL())
        RequestController.connectNotification(Configuration._errorMessage)

    def __del__(self):
        #""" destructor for the singleton instance, stops logging
        #"""
        self._stopLogging()

    def _configValue(self, key, logError = False):
       """ gets the value of a config key
    
       Parameters:
            key (str):  name of the config key
            logError (bool): if True: logs any error, e.g. "key not found"
    
       Returns:
            value of the key/value pair
       """
       try:
           return self._configuration[key] #.get(key)
       except:
           if logError:
               self._print("Config Key {0} could not be found!".format(key), logging.ERROR)
           return None

    def _getFilePath(self, filePath, fileName, create):
        if not fileName:
            return None
        if os.path.isabs(fileName):
            return fileName
        path = self._basePath
        if filePath:
            path = os.path.join(path, filePath)
        fileName = os.path.join(path, fileName)
        path = os.path.split(fileName)[0]
        if create and not os.path.exists(path):
            os.mkdir(path)
        return fileName

    def _getInputFilePath(self, fileName):
        return self._getFilePath(self._inputDataPath, fileName, False)

    def _getTempFilePath(self, fileName):
        return self._getFilePath(self._tempDataPath, fileName, True)

    def _getOutputFilePath(self, fileName):
        return self._getFilePath(self._outputDataPath, fileName, True)

    def _startLogging(self, fileName, level=logging.DEBUG):
        self._stopLogging()
        if fileName:
            handler = logging.FileHandler(fileName)
            if handler is not None:
                handler.setLevel(level)
                handler.setFormatter(logging.Formatter('%(asctime)s %(message)s'))
                log = logging.root
                log.addHandler(handler)
                log.setLevel(level)
                self._isLogging = True
    
    def _stopLogging(self):
        if self._isLogging:
            RequestController.connectNotification(None)
            self._isLogging = False
            log = logging.root
            for hdlr in log.handlers[:]:
                log.removeHandler(hdlr)

    def _print (self, message, level=logging.DEBUG):
        if self._showConsoleLogging:
            print("{0} - {1}".format(datetime.now(), message))
        if self._isLogging:
            try:
                logging.log(level, message)
            except:
                pass

        
Configuration.load()