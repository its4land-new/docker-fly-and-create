from .toolwrapper.wrapper import main

main.startWrapper()