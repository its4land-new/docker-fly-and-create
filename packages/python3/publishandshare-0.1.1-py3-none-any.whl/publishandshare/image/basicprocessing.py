# -*- coding: utf-8 -*-
"""
/***************************************************************************
 its4land WP6: PublishLayer
                              -------------------
        begin                : 2019-01-14
        git sha              : $Format:%H$
        copyright            : (C) 2019 by Reiner Borchert, Hansa Luftbild AG Münster
        email                : borchert@hansaluftbild.de
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

"""
!/bin/python
-*- coding: utf-8 -*

### Author ###
 Reiner Borchert, 2019

### Description ###
 abstract base class for processing
"""

import os
import sys
from datetime import *
import logging
import json
from .requestcontroller import RequestController

class BasicProcessing():
    
    CONFIG_FILENAME = 'share/config/config.json'
    
    def __init__(self, config_file = CONFIG_FILENAME):
        self._base_path = os.path.split(__file__)[0]
        config_file_path = os.path.join(self._base_path, config_file)
        self._configuration = json.load(open(config_file_path))
        self._temp_data_path = self._config_value("TempDataPath")
        self._is_logging = False
        self._show_console_logging = self._config_value("ShowConsoleLogging") > 0
        self.start_logging(self.get_temp_file_path(self._config_value("LogfileName")))
        RequestController.connect_notification(self._print_error)
        
    def __del__(self):
        self.stop_logging()

    def _config_value(self, key):
       try:
           return self._configuration[key]
       except:
           self._print("Config Key {0} could not be found!".format(key), logging.ERROR)
           return None

    def get_application_name(self):
        return self.__class__.__name__

    def get_temp_file_path(self, filename):
        if not filename:
            return None
        if os.path.isabs(filename):
            return filename
        #path = os.path.join(self._base_path, self._temp_data_path)
        path = os.path.join(os.path.dirname(sys.argv[0]), self._temp_data_path)
        if not os.path.exists(path):
            os.makedirs(path)
        return os.path.join(path, filename)

    def start_logging(self, filename, level=logging.DEBUG):
        self.stop_logging()
        if filename:
            handler = logging.FileHandler(filename)
            if handler is not None:
                handler.setLevel(level)
                handler.setFormatter(logging.Formatter('%(asctime)s %(message)s'))
                log = logging.root
                log.addHandler(handler)
                log.setLevel(level)
                self._is_logging = True
                self._print('*** Start Logging for "{0}" ***'.format(self.get_application_name()), logging.INFO)
    
    def stop_logging(self):
        if self._is_logging:
            RequestController.connect_notification(None)
            self._print('*** Stop Logging for "{0}" ***'.format(self.get_application_name()), logging.INFO)
            self._is_logging = False
            log = logging.root
            for hdlr in log.handlers[:]:
                log.removeHandler(hdlr)

    def _print (self, message, level=logging.DEBUG):
        if self._show_console_logging:
            print("{0} - {1}".format(datetime.now(), message))
        if self._is_logging:
            try:
                logging.log(level, message)
            except:
                pass

    def _print_error(self, title, message, exception = None):
        self._print(message, level=logging.ERROR)

