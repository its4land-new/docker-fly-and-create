# -*- coding: utf-8 -*-
"""
/***************************************************************************
        begin                : 2019-01-14
        git sha              : $Format:%H$
        copyright            : (C) 2019 by Reiner Borchert, Hansa Luftbild AG Münster
        email                : borchert@hansaluftbild.de
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import io
import json

from requests import Session

def decodeJSONResponse(content):
    """ decode response content as utf8 if it is of type bytes """
    if isinstance(content, bytes):
        return content.decode('utf8')
    return content

class RequestController:
    
    __notify_function = None
    _current_session = None
    
    @staticmethod
    def connect_notification (func):
        RequestController.__notify_function = func

    @staticmethod
    def create_current_session (username = None, password = None):
        RequestController._current_session = RequestController._get_session(True, username, password)

    @staticmethod
    def reset_current_session ():
        if RequestController._current_session is not None:
            try:
                RequestController._current_session.close()
            finally:
                RequestController._current_session = None

    @staticmethod
    def _get_session (create, username = None, password = None):
        if create:
            session = Session()
            if username:
                 session.auth = (username, password)
            return session
        else:
            return RequestController._current_session

    # -------------------------------------------------------------------------- #
    
    @staticmethod
    def send_get_request (url, request_data, use_cur_session=True):
        try:
            session = RequestController._get_session(not use_cur_session)
            if session is not None:
                response = session.get(url, params=request_data)
                if RequestController._check_response_error(response):
                    return decodeJSONResponse(response.content)
        except Exception as e:
            RequestController._log_request_error (url, e)
        finally:
            if not use_cur_session and session is not None:
                session.close() 
        return None

    @staticmethod
    def send_put_request (url, request_data):
        try:
            session = RequestController._get_session(False)
            if session is not None:
                response = session.put(url, json=request_data)
                if RequestController._check_response_error(response):
                    return decodeJSONResponse(response.content)
        except Exception as e:
            RequestController._log_request_error (url, e)
        finally:
            pass 
        return None

    @staticmethod
    def send_patch_request (url, request_data):
        try:
            session = RequestController._get_session(False)
            if session is not None:
                response = session.patch(url, data=request_data)
                if RequestController._check_response_error(response):
                    return decodeJSONResponse(response.content)
        except Exception as e:
            RequestController._log_request_error (url, e)
        finally:
            pass 
        return None

    @staticmethod
    def send_post_request (url, request_data, use_cur_session=True):
        try:
            session = RequestController._get_session(not use_cur_session)
            if session is not None:
                print(request_data)
                response = session.post(url, json=request_data)
                if RequestController._check_response_error(response):
                    return decodeJSONResponse(response.content)
        except Exception as e:
            RequestController._log_request_error (url, e)
        finally:
            if not use_cur_session and session is not None:
                session.close() 
        return None

    @staticmethod
    def send_json_request (url, request_data):
        try:
            session = RequestController._get_session(False)
            if session is not None:
                response = session.post(url, json=request_data)
                if RequestController._check_response_error(response):
                    return decodeJSONResponse(response.content)
        except Exception as e:
            RequestController._log_request_error (url, e)
        return None

    @staticmethod
    def send_post_formdata_request (url, request_data, upload_file = None):
        try:
            files = None
            session = RequestController._get_session(False)
            if session is not None:
                if upload_file:
                    files = {'document': open(upload_file,'rb')}
                response = session.post(url, data=request_data, files=files)
                if RequestController._check_response_error(response):
                    return decodeJSONResponse(response.content)
        except Exception as e:
            RequestController._log_request_error (url, e)
        finally:
            if files:
                for (key, value,) in files.items():
                    if isinstance(value, io.IOBase):
                        # If value is an open filestream close it
                        value.close()
        return None

    @staticmethod
    def send_delete_request (url, request_data):
        try:
            session = RequestController._get_session(False)
            if session is not None:
                response = session.delete(url) #, requestData)
                if RequestController._check_response_error(response):
                    return decodeJSONResponse(response.content)
        except Exception as e:
            RequestController._log_request_error (url, e)
        return None
    
    @staticmethod
    def download_file (url, filename, use_cur_session=True):
        try:
            session = RequestController._get_session(not use_cur_session)
            if session is not None:
                if not filename:
                    filename = url.split('/')[-1]
                response = session.get(url, stream=True)
                if RequestController._check_response_error(response):
                    with open(filename, 'wb') as f:
                        for chunk in response.iter_content(chunk_size=4096): 
                            if chunk: # filter out keep-alive new chunks
                                f.write(chunk)
                    return filename
        except Exception as e:
            RequestController._log_request_error (url, e)
        finally:
            if not use_cur_session and session is not None:
                session.close() 
        return None

    # -------------------------------------------------------------------------- #
    
    _lastMessage = None
    
    @staticmethod
    def get_content_item(content, item_id):
        if content and item_id:
            return content.get(item_id)
        return None

    @staticmethod
    def response_to_content(response):
        if response is not None:
            items = RequestController.str_to_dict(response.content)
            RequestController._lastMessage = None
            if items is None:
                RequestController._lastMessage = "no content"
            else:
                success = RequestController.get_content_item(items, 'success')
                if not success:
                    RequestController._lastMessage = RequestController.get_content_item(items, 'message')
                    if not RequestController._lastMessage:
                        RequestController._lastMessage = "unknown"
            if RequestController._lastMessage is None:
                return items
            else:
                RequestController._log_response_error (response.url, response.status_code, RequestController._lastMessage)
        return None

    @staticmethod
    def last_message():
        try:
            return RequestController._lastMessage
        finally:
            RequestController._lastMessage = None

    @staticmethod
    def content_to_result(content):
        if content:
            result = RequestController.get_content_item(content, 'result')
            if result is None:
                return []
            return result
        return None

    @staticmethod
    def response_to_result(response):
        return RequestController.content_to_result(RequestController.response_to_content(response))

    @staticmethod
    def str_to_dict(content):
        if content is not None:
            try:
                return json.loads(content)
            except Exception as e:
                if RequestController.__notify_function is not None:
                    RequestController.__notify_function(u'JSON', u'Error on JSON decoding: {0} - message: {1}'.format(content, str(e)), e)
        return None

    @staticmethod
    def _check_response_error (response):
        if response is not None:
            if response.ok and response.content is not None:
                return True
            RequestController._log_response_error (response.url, response.status_code, response.reason)
        return False

    # -------------------------------------------------------------------------- #
    
    @staticmethod
    def _log_request_error (url, exception):
        if RequestController.__notify_function is not None:
            RequestController.__notify_function(u'RequestController', u'Error on sending RequestController to {0}: {1}'.format(url, str(exception)), exception)

    @staticmethod
    def _log_response_error (url, code, msg):
        if RequestController.__notify_function is not None:
            RequestController.__notify_function(u'Response', u'Error on url {0} - code {1}: {2}'.format(url, code, msg))

