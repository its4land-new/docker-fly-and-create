"""Gather Image metadata

@author: Mohammed Imaduddin Humayun
@email: humayumo@hansaluftbild.de
@copyright: Hansa Luftbild, 2019
"""

from osgeo import gdal

def get_image_metadata(image):
    """Return image metadata as JSON."""
    info_options = gdal.InfoOptions(format='json')
    dataset = gdal.Open(image)
    info = gdal.Info(dataset, options=info_options)
    return info

def get_extent(image):
    """Return image extent as WGS84 lat-lon."""
    info = get_image_metadata(image)
    return info['wgs84Extent']
